import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import OfficersList from './components/OfficersList';
import AddOfficerForm from './components/AddOfficerForm';
import OfficerDetail from './components/OfficerDetail';

const API_BASE_URL = 'http://localhost:5000/api';

function App() {
  const [view, setView] = useState('dashboard'); // dashboard, add, detail
  const [officers, setOfficers] = useState([]);
  const [selectedOfficer, setSelectedOfficer] = useState(null);
  const [filter, setFilter] = useState({ rank: '', readyForPromotion: '' });
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('createdAt');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const RANKS = {
    PROMOTABLE: ['Recruit', 'Officer', 'Corporal', 'Sergeant', 'Staff Sergeant'],
    APPOINTMENT: ['Lieutenant', 'Captain', 'Major']
  };

  // Fetch officers
  const fetchOfficers = async () => {
    setLoading(true);
    try {
      let url = `${API_BASE_URL}/officers?`;
      if (filter.rank) url += `rank=${filter.rank}&`;
      if (filter.readyForPromotion) url += `readyForPromotion=${filter.readyForPromotion}&`;
      if (search) url += `search=${search}&`;
      url += `sortBy=${sortBy}`;

      const response = await axios.get(url);
      setOfficers(response.data);
      setError('');
    } catch (err) {
      setError('Failed to fetch officers: ' + err.message);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchOfficers();
  }, [filter, search, sortBy]);

  // Handle add officer
  const handleAddOfficer = async (formData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/officers`, formData);
      setOfficers([response.data, ...officers]);
      setView('dashboard');
      setError('');
    } catch (err) {
      setError('Failed to add officer: ' + err.message);
    }
  };

  // Handle update officer
  const handleUpdateOfficer = async (id, updateData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/officers/${id}`, updateData);
      setOfficers(officers.map(o => o._id === id ? response.data : o));
      if (selectedOfficer && selectedOfficer._id === id) {
        setSelectedOfficer(response.data);
      }
      setError('');
    } catch (err) {
      setError('Failed to update officer: ' + err.message);
    }
  };

  // Handle promote officer
  const handlePromoteOfficer = async (officerId, toRank, promotedBy = 'Admin') => {
    try {
      const response = await axios.post(`${API_BASE_URL}/promotions/promote/${officerId}`, {
        toRank,
        promotedBy
      });
      setOfficers(officers.map(o => o._id === officerId ? response.data : o));
      if (selectedOfficer && selectedOfficer._id === officerId) {
        setSelectedOfficer(response.data);
      }
      setError('');
    } catch (err) {
      setError('Failed to promote officer: ' + err.message);
    }
  };

  // Handle delete officer
  const handleDeleteOfficer = async (id) => {
    if (window.confirm('Are you sure you want to delete this officer?')) {
      try {
        await axios.delete(`${API_BASE_URL}/officers/${id}`);
        setOfficers(officers.filter(o => o._id !== id));
        setView('dashboard');
        setError('');
      } catch (err) {
        setError('Failed to delete officer: ' + err.message);
      }
    }
  };

  // View officer details
  const handleViewOfficer = (officer) => {
    setSelectedOfficer(officer);
    setView('detail');
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>🚔 ISRP PD Rank Tracker</h1>
        <p>Manage officer promotions and rank progression</p>
      </header>

      {error && <div className="error-message">{error}</div>}

      <nav className="app-nav">
        <button 
          className={`nav-btn ${view === 'dashboard' ? 'active' : ''}`}
          onClick={() => setView('dashboard')}
        >
          Dashboard
        </button>
        <button 
          className={`nav-btn ${view === 'add' ? 'active' : ''}`}
          onClick={() => setView('add')}
        >
          Add Officer
        </button>
      </nav>

      <main className="app-main">
        {view === 'dashboard' && (
          <div className="dashboard">
            <div className="filters-section">
              <div className="filter-group">
                <label>Rank:</label>
                <select 
                  value={filter.rank}
                  onChange={(e) => setFilter({ ...filter, rank: e.target.value })}
                >
                  <option value="">All Ranks</option>
                  {[...RANKS.PROMOTABLE, ...RANKS.APPOINTMENT].map(rank => (
                    <option key={rank} value={rank}>{rank}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label>Status:</label>
                <select 
                  value={filter.readyForPromotion}
                  onChange={(e) => setFilter({ ...filter, readyForPromotion: e.target.value })}
                >
                  <option value="">All</option>
                  <option value="true">Ready for Promotion</option>
                  <option value="false">Not Ready</option>
                </select>
              </div>

              <div className="filter-group">
                <label>Search:</label>
                <input 
                  type="text"
                  placeholder="Officer name..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>

              <div className="filter-group">
                <label>Sort by:</label>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                >
                  <option value="createdAt">Date Added</option>
                  <option value="name">Name</option>
                  <option value="rank">Rank</option>
                  <option value="daysInRank">Time in Rank</option>
                </select>
              </div>
            </div>

            {loading ? (
              <div className="loading">Loading officers...</div>
            ) : (
              <OfficersList 
                officers={officers}
                onViewOfficer={handleViewOfficer}
                onUpdateReady={(id, ready) => handleUpdateOfficer(id, { readyForPromotion: ready })}
              />
            )}
          </div>
        )}

        {view === 'add' && (
          <div className="add-officer-section">
            <AddOfficerForm onSubmit={handleAddOfficer} ranks={[...RANKS.PROMOTABLE, ...RANKS.APPOINTMENT]} />
          </div>
        )}

        {view === 'detail' && selectedOfficer && (
          <OfficerDetail 
            officer={selectedOfficer}
            onClose={() => setView('dashboard')}
            onUpdate={handleUpdateOfficer}
            onPromote={handlePromoteOfficer}
            onDelete={handleDeleteOfficer}
            ranks={[...RANKS.PROMOTABLE, ...RANKS.APPOINTMENT]}
            allOfficers={officers}
          />
        )}
      </main>
    </div>
  );
}

export default App;
